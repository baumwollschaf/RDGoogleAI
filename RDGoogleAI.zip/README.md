# RDGoogleAI
Google AI API Delphi Component. To be continued when API available in Germany
Delphi implementation and component of Google AI API.

All you need is an own API key from here: https://aistudio.google.com/app/apikey

Copyright © 2024 Ralph Dietrich.
