# RDGoogleAI
Delphi implementation of GoogleAI, Gemini API - event based, asynchronous.
To be continued when API available in Germany.

All you need is an own API key from here: https://aistudio.google.com/app/apikey

Copyright © 2024 Ralph Dietrich.

E-Mail: baumwollschaf@gmail.com
